import statistics
def sd(a,b):
  #This part is like the standard deviation checker
  mean=statistics.mean(b)
  newa=[]
  for i in a:
    newa.append((i-mean)**2)
  newmean=statistics.mean(newa)
  sd=newmean**(1/2)
  return sd
  #sd means standard deviation
  #-----------------------------------
def Bc(a,b):
  meana=statistics.mean(a)
  meanb=statistics.mean(b)
  newa=[]
  newb=[]
  ever=[]
  ab=0
  asq=[]
  bsq=[]
  for i in a:
    newa.append(i-meana)
    asq.append((i-meana)**2)
  for i in b:
    newb.append(i-meanb)
    bsq.append((i-meanb)**2)
  for i in range(len(a)):
    ever.append(newa[i]*newb[i])
  ever=sum(ever)
  asq=sum(asq)
  bsq=sum(bsq)
  #print(ever/((asq*bsq)**(1/2)))
  return ever/((asq*bsq)**(1/2))
def best_fit(X, Y):
    xbar = sum(X)/len(X)
    ybar = sum(Y)/len(Y)
    n = len(X)
    numer = sum([xi*yi for xi,yi in zip(X, Y)]) - n * xbar * ybar
    denum = sum([xi**2 for xi in X]) - n * xbar**2
    b = numer / denum
    a = ybar - b * xbar
    #print('best fit line:\ny = {:.2f} + {:.2f}x'.format(a, b))
    return a, b
def AIFlood():
  datafordates=[1927,1973,1995,2005,2011,2015,2016]
  Y=[]
  sub=int(datafordates[0])
  for i in range(len(datafordates)):
    datafordates[i]=int(datafordates[i])-sub
    Y.append(i+1)
  ogdata=[]
  for i in datafordates:
    ogdata.append(i)
  a, b = best_fit(Y,datafordates)
  frml=(b*(len(Y)+1)+a)+sub
  cc=Bc(datafordates,Y)
  subtract=0
  for gen in range(5):
    optimizeddata=[]
    for i in range(len(datafordates)):
      optimizeddata.append(datafordates[i]-((b*(Y[i]+1)+a)))
    subtract=statistics.mean(optimizeddata)
    optimizeddata=[]
    for i in range(len(datafordates)):
      datafordates[i]=datafordates[i]+subtract
    a, b = best_fit(Y,datafordates)
    frml=(b*(len(Y)+1)+a)+sub
  bc=sd(datafordates,ogdata)
  st=0
  while ((b*(st+1)+a))+sub <2019:
    st=st+1
  return ((b*(st+1)+a))+sub
