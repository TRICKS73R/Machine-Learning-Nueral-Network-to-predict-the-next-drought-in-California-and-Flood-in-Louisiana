import random, string
from floodtime import *
from timedrought import *
from flask import Flask, render_template

app = Flask(__name__, template_folder='templates', static_folder='static')
ok_chars = string.ascii_letters + string.digits


@app.route('/')
def base_page():
  return render_template('index.html')


@app.route("/floods")
def floods():
  return render_template("floods.html")


@app.route("/droughts")
def droughts():
  return render_template("Droughts.html")

@app.route("/predictions")
def predictions():
  return render_template("Predictions.html",Drought=AIDrought(),Flood=AIFlood())


@app.route("/aboutus")
def aboutus():
  return render_template("AboutUs.html")









if __name__ == "__main__":
    app.run(host='0.0.0.0', port=random.randint(2000, 9000))
